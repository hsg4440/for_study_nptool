#include<iostream>
#include<math.h>
#include<vector>
#include<fstream>
#include<cstdlib>
#include<ctime>

#include"mini.h"
using namespace std;

minimisation::minimisation()
{
}

minimisation::~minimisation()
{
}

void minimisation::initialise(string empl)
{
  fich=empl;
}

string minimisation::read()
{
  return fich;
}

mcarres::mcarres(double* ath, double* bth)
  :minimisation()
{
  a=ath;
  b=bth;
  khi2=0;
}

mcarres::~mcarres()
{
}

double mcarres::read()
{
  return khi2;
}

void mcarres::initialise()
{
  double x,y;
  double k; /// y' = ath*x' + bth
  k=0;
  double va,vb;
  va=*a;
  vb=*b;
  fstream fs(minimisation::read(),ios::in);
  while (fs >> x >> y){
    //cout << x << " " << y << endl;
    k = k + (va*x+vb-y)*(va*x+vb-y)/(y*y);}
  khi2= k;
}

fonction::fonction()
  :minimisation()
{
}

fonction::fonction(double* x1)
  :minimisation()
{
  x=x1;
}


fonction::~fonction()
{
}

double fonction::fct()
{
  double vx=*x;
  return vx*vx*((vx*(vx+1)-3)*vx*vx+5)-6;
}

dist::dist(int n1,int*li)
  :minimisation()
{
  n=n1;
  liste=li;
}

dist::~dist()
{
}

void dist::set()
{
  fstream fs(minimisation::read(),ios::in);
  double**tab= (double**)malloc(n*sizeof(double));
  double x;
  for(int i=0;i<n;i++)
    tab[i]= (double*)malloc(i*sizeof(double));
  for (int i=0;i<n;i++)
    for(int j=0;j<i;j++){
      fs >> x;
      tab[i][j] = x ;
    }
  for (int i=0;i<n;i++){
    for(int j=0;j<i;j++){
      //cout << tab[i][j] << " ";
    }
    //cout << endl;
  }
  mat=tab;
}
  
void dist::initialise()
{
  double l=0;
  int a,b;
  for(int i=0;i<n-1;i++){
    a=liste[i];
    b=liste[i+1];
    if (a>b)
      l = l + mat[a][b];
    else
      l = l + mat[b][a];
    //cout << l  << " " << a << " " << b << " "<< endl;
  }
  distance=l;
}

double dist::read()
{
  return distance;
}


