#ifndef data_h
#define data_h 1

#include<iostream>
#include<fstream>

using namespace std;


// La classe data génère des données dans fich utilisables par les méthodes des autres classes

class data
{
 public:
  data();
  ~data();

  virtual void initialise(string empl);  // Fichier de données stocké dans fich
  string read();
  
  
  
 private:
  string fich;
  

};

class lin: public data
{
 public:
  lin(double a1, double b1,  int n1);
  ~lin();

  void initialise();   // génération de données suivant une loi linéaire ax + b dans le fichier fich
  double reada();
  double readb();
  int readn(); 

 private:
  double a;
  double b;
  int n;

};

class ling: public data
{
 public:
  ling(double a1, double b1, int n1, double ampl1, double etype1);
  ~ling();



  void initialise();   // génération de données suivant une loi linéaire ax + b + bruit_gaussien(ampl,etype)  dans le fichier fich



  
 private:
  double ampl;
  double etype;
  double a;
  double b;
  double n;

};

class tab: public data
{
 public:
  tab(int  n1,  double lmax1, double lmin1);  
  ~tab();

  void initialise();   // génération d'un tableau triangulaire de données de taille n et de valeur suivant une loi uniforme entre lmin et lmax

 private:
  double n;
  double lmin;
  double lmax;
};
    

#endif
