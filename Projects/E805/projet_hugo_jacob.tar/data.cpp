#include<iostream>
#include<math.h>
#include<vector>
#include<fstream>
#include<cstdlib>
#include<ctime>
#include<random>
#include"data.h"

using namespace std;

data::data()
{
}


data::~data()
{
}

void data::initialise(string empl)
{
  fich=empl;
}

string data::read()
{
  return fich;
}



lin::lin(double a1, double b1, int n1)
  :data()
{
  a=a1;
  b=b1;
  n=n1;
}

lin::~lin()
{
}

double lin::reada()
{
  return a;
}

double lin::readb()
{
  return b;
}

int lin::readn()
{
  return n;
}

 void lin::initialise()
{
  srand(time(NULL));
  fstream f;
  f.open(data::read(),ios::out);
  int k;
  double x,fct;
  for(k=0;k<n;k++){
    x=((rand() % 101)-50);
    fct=a*x+b;
    f  <<  x  << " " << fct << endl;
  }
  f.close();
}
    
ling::ling(double a1, double b1, int n1, double ampl1, double etype1)
  :data()
{
  a=a1;
  b=b1;
  n=n1;
  ampl=ampl1;
  etype=etype1;
}

ling::~ling()
{
}



void ling::initialise()
{
  srand(time(NULL));
  fstream f;
  default_random_engine generator;
  normal_distribution<double> distrib(0.,etype);
  f.open(data::read(),ios::out);
  int k;
  double x,fct;
  for(k=0;k<n;k++){
    x=((rand() % 101)-50);
    fct=a*x+b+distrib(generator)*ampl;
    f  <<  x  << " " << fct << endl;
  }
  f.close();
}

tab::tab(int n1, double lmin1, double lmax1)
  :data()
{
  n=n1;
  lmin=lmin1;
  lmax=lmax1;
}

tab::~tab()
{
}

void tab::initialise()
{
  srand(time(NULL));
  random_device rd;
  mt19937 generator(rd());
  fstream f;
  uniform_real_distribution<double> distrib(lmin,lmax);
  f.open(data::read(),ios::out);
  int k,i;
  for(k=0;k<n;k++){
    for(i=0;i<k;i++)
      f << distrib(generator) << " ";
    f << endl;
  }
  f.close();
}
      
      
