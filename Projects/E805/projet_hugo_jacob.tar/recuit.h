#ifndef recuit_h
#define recuit_h 1

#include<iostream>
#include<vector>
#include<Python.h>

using namespace std;

// La classe recuit contient les algorithmes de calcul utilisant la méthode de M-H

class recuit
{
 public:
  recuit();
   ~recuit();

   virtual void MetroHast(string empl); // On indique de quel fichier proviennent les données dans fich
  virtual void plot();
  string read();

 private:
  string fich;
 
};




class dim1: public recuit
{
 public:
  dim1();
  dim1(double lambd, double ini, double final, double pa);
  ~dim1();

  void MetroHast();  //  Calcul du minimum stocké dans réponse d'une fonction d'optimisation de dimension 1
  double read();  // Affichage
  void plot();

  private:
  double tini;
  double tfinale;
  double pas;
  double lambda;
  double reponse;
};






class dim2: public recuit
{
 public:
  dim2();
  dim2(double lambd, double ini, double final, double pa);
  ~dim2();

  void MetroHast(); // Calcul de l'optimisation pour une fonction linéaire avec ou sans bruit gaussien
  double reada();
  double readb();
  void plot();  // Affichage

  private:
  double tini;
  double tfinale;
  double pas;
  double lambda;
  double lina;
  double linb;
};







  
class voy: public recuit
{
 public:
  voy();
  voy(double lambd, double ini, double final,  int n1);
  ~voy();

  void MetroHast(); //Calcul de la distance minimale et du chemin pour le problème du voyageur de commerce
  double read(); // Affichage
  void plot();

 private:

  double tini;
  double tfinale;
  double pas;
  double lambda;
  double reponse;
  int n;
};












  


#endif
