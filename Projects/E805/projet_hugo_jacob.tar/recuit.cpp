#include<iostream>
#include<math.h>
#include<vector>
#include<fstream>
#include<cstdlib>
#include<ctime>
#include<sstream>
#include<Python.h>


#include<string.h>
#include"recuit.h"
#include"mini.h"
using namespace std;

void make_plot_py(ostringstream &ss)
{
  ostringstream run_py;
  run_py
    << "from numpy import *\n"
    << "from matplotlib.pyplot import *\n"
    << "from matplotlib.animation import *\n"
    << "from mpl_toolkits.mplot3d import Axes3D\n"
    << ss.str()
    << "show()"
    ;
  // cout << run_py.str() << endl;
  Py_Initialize();
  PyRun_SimpleString(run_py.str().c_str());
  Py_Finalize();
}

recuit::recuit()
{
}



recuit::~recuit()
{
}

string recuit::read()
{
  return fich;
}

void recuit::MetroHast(string empl)
{
  fich=empl;
}

void recuit::plot()
{
}


////// classe dim1


dim1::dim1()
  :recuit()
{
}

dim1::dim1(double lambd, double ini, double final, double pa)
  :recuit()
{
  tini= ini;
  tfinale=final;
  pas=pa;
  lambda=lambd;
}

dim1::~dim1()
{
}


void dim1::MetroHast() 
{
  fstream fich;
  double min;
  double x;
  double xcan;
  double deltx;
  double delt;
  double t;
  fonction obj(&x);
  fonction objcan(&xcan);
  fonction objmin(&min);
  min=obj.fct();
  deltx=pas;
  x=0;
  t=tini;
  fich.open("MetroHast1.res",ios::out);
  while (t>tfinale)
    {
      xcan= x+deltx;
      delt = objcan.fct()-obj.fct();
      if (exp(-delt/t)>=(double(rand())/double(RAND_MAX))){
	
	x=xcan;
	fich << x << " " << obj.fct() << endl;
      }
      else
	deltx = - deltx;
      if (objmin.fct()>obj.fct())
	min = x;
      t=t*lambda;
      //cout << x << "  " << min << endl;
    }
  reponse=min;
  fich.close();
 
}

void dim1::plot()
{
  ostringstream pyth;
  pyth
    << "l=loadtxt('MetroHast1.res')\n"
    << "x=l[:,0]\n"
    << "y=l[:,1]\n"
    << "plot(x,y,label='Portion de f(x) parcourue')\n"
    << "xlabel('x')\n"
    << "ylabel('f(x)')\n"
    << "legend(loc=9)\n"
    ;
  make_plot_py(pyth);
}

double dim1::read()
{
  return reponse;
}

//////////////////// classe dim2

dim2::dim2()
  :recuit()
{
}

dim2::dim2(double lambd, double ini, double final, double pa)
  :recuit()
{
  tini= ini;
  tfinale=final;
  pas=pa;
  lambda=lambd;
}

dim2::~dim2()
{
}

void dim2::MetroHast() 
{
  fstream fich;
  double minx,miny;
  double x,y;
  double xcan,ycan;
  double deltx,delty;
  double delt;
  double t;
  double a,b,c;
  
  minx=0;
  miny=0;
  deltx=pas;
  delty=pas;
  x=0;
  y=0;
  xcan= x+deltx;
  ycan= y+delty;
  t=tini;
  srand(time(NULL));
  mcarres obj(&x,&y);
  mcarres objcan(&xcan,&ycan);
  mcarres objmin(&minx,&miny);
  obj.minimisation::initialise(recuit::read());
  objcan.minimisation::initialise(recuit::read());
  objmin.minimisation::initialise(recuit::read());
  fich.open("MetroHast2.res",ios::out);
  //cout << t << " " << tini << " " << tfinale << endl;
  while (t>tfinale)
    {
      xcan= x+deltx;
      ycan= y+delty;
      objcan.initialise();
      a=objcan.read();
      obj.initialise();
      b=obj.read();
      objmin.initialise();
      c=objmin.read();
      delt = a-b;
      if (exp(-delt/t)>=(double(rand())/double(RAND_MAX))){
	
	x=xcan;
	y=ycan;
	fich << x << " "  << y  << " " << b << endl;
      }
      else{
	
	deltx = (((rand() % 2)-0.5)*2)* deltx;
	delty = (((rand() % 2)-0.5)*2)* delty;
      }
      if (c>b){
	minx = x;
	miny = y;
      }
	
      t=t*lambda;
      //cout << x << "  " << min << endl;
    }
  lina = minx;
  linb = miny;
  fich.close();
 
  cout << endl;
}

void dim2::plot()
{
  ostringstream pyth;
   pyth
    << "l=loadtxt('MetroHast2.res')\n"
    << "x=l[:,0]\n"
    << "y=l[:,1]\n"
    << "z=l[:,2]\n"
    << "gca(projection='3d').scatter(x,y,z)\n"
    << "plot(x,y,z,label='Portion de Khi(a,b) parcourue')\n"
    << "xlabel('a')\n"
    << "ylabel('b')\n"
    << "legend()\n"
    ;
  make_plot_py(pyth);
}


double dim2::reada()
{
  return lina;
}

double dim2::readb()
{
  return linb;
}

////// classe voy

voy::voy()
  :recuit()
{
}


voy::voy(double lambd, double ini, double final, int n1)
  :recuit()
{
  tini= ini;
  tfinale=final;
  lambda=lambd;
  n=n1;
}

voy::~voy()
{
}

void voy::MetroHast() ///////////
{
  srand(time(NULL));
  double a,b,c;
  int i1,i2;
  fstream fich;
  double min;
  int*li=(int*)malloc(n*sizeof(int));
  int*lican=(int*)malloc(n*sizeof(int));
  int*limin=(int*)malloc(n*sizeof(int));
  double delt;
  double t;
  dist obj(n,li);
  dist objcan(n,lican);
  dist objmin(n,limin);
  obj.minimisation::initialise(recuit::read());
  objcan.minimisation::initialise(recuit::read());
  objmin.minimisation::initialise(recuit::read());
  obj.set();
  objcan.set();
  objmin.set();
  for(int k=0;k<n;k++)
    li[k]=k;
  for(int k=0;k<n;k++)
    limin[k]=k;
  objmin.initialise();
  min=objmin.read();
  t=tini;
  fich.open("MetroHast3.res",ios::out);
  while (t>tfinale)
    {
      i1= rand() % n;
      i2= rand() % n;
      for(int k=0;k<n;k++)
	  lican[k]=li[k];
      lican[i1]=li[i2];
      lican[i2]=li[i1];
      obj.initialise();
      objcan.initialise();
      objmin.initialise();
      a=obj.read();
      b=objcan.read();
      c=objmin.read();
      delt= b-a;
      if (exp(-delt/t)>=(double(rand())/double(RAND_MAX))){
	
	for(int k=0;k<n;k++){
	  li[k]=lican[k];
	}
	fich << t << " " << b << endl;
      }
      if (c > b){
	for(int k=0;k<n;k++){
	  limin[k]=lican[k];
	}
	min = b;
      }
      t=t*lambda;
      //cout << x << "  " << min << endl;
    }
  reponse=min;
  cout << endl << "L'ordre de parcours des " << n << " villes dans la configuration optimale est: " << endl;
  for(int k=0;k<n;k++)
    cout << limin[k] << " ";
  cout << endl << endl;
  fich.close();
  
    
}

void voy::plot()
{
  ostringstream pyth;
  pyth
    << "l=loadtxt('MetroHast3.res')\n"
    << "x=l[:,0]\n"
    << "y=l[:,1]\n"
    << "plot(x,y,label='Evolution de la longueur du parcours')\n"
    << "xlabel('Temperature')\n"
    << "ylabel('Longueur totale du parcours')\n"
    << "legend(loc=9)\n"
    ;
  
  make_plot_py(pyth);
  }







double voy::read()
{
  return reponse;
}
